import { useState } from "react";

const ProductForm = ({ onAddProduct }) => {
  const [productName, setProductName] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState("");
  const [inStock, setInStock] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!productName || price <= 0 || !category) {
      setError("Please fill all fields correctly.");
      return;
    }

    const newProduct = { productName, price, category, inStock };
    onAddProduct(newProduct);
    setProductName("");
    setPrice("");
    setCategory("");
    setInStock(false);
    setError("");
  };

  return (
    <form className="space-y-4" onSubmit={handleSubmit}>
      {error && <div className="text-red-500">{error}</div>}
      <input
        className="input"
        type="text"
        value={productName}
        onChange={(e) => setProductName(e.target.value)}
        placeholder="Product Name"
      />
      <input
        className="input"
        type="number"
        value={price}
        onChange={(e) => setPrice(e.target.value)}
        placeholder="Price"
      />
      <select
        className="input"
        value={category}
        onChange={(e) => setCategory(e.target.value)}
      >
        <option value="">Select Category</option>
        <option value="Electronics">Electronics</option>
        <option value="Clothing">Clothing</option>
        <option value="Books">Books</option>
      </select>
      <label className="flex items-center">
        <input
          type="checkbox"
          checked={inStock}
          onChange={() => setInStock(!inStock)}
        />
        In Stock
      </label>
      <button type="submit" className="btn">Add Product</button>
    </form>
  );
};

export default ProductForm;