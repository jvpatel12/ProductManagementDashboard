import React from 'react'

export default function ProductItem({product,onDelete}) {
   return (
    <li className="flex justify-between items-center">
      <div>
        <p>{product.productName}</p>
        <p>{product.price} USD</p>
        <p>{product.category}</p>
        <p>{product.inStock ? "In Stock" : "Out of Stock"}</p>
      </div>
      <div className="space-x-2">
        {/* <button onClick={onEdit} className="btn">Edit</button> */}
        <button onClick={onDelete} className="btn text-red-500">Delete</button>
      </div>
    </li>);
}
