import React from "react";
import ProductItem from "./ProductItem";

function ProductList({ products = [], onDeleteProduct = () => {}, editProduct = () => {} }) {
  return(
     <div>
        <h1>Product List </h1>
        {products.length === 0 ? (<p>
         No products found
        </p> ): (
            <ul>
          {products.map((product, index) => (
            <ProductItem
              key={index}
              product={product}
              onDelete={() => onDeleteProduct(index)}
              onEdit={() => editProduct(index)}
            />
          ))}
        </ul>

        )}
     </div>
  );
}

export default ProductList;


