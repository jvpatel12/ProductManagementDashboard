import React from "react";
import { useState } from "react";
import ProductForm from "./components/ProductForm.jsx";
import ProductList from "./components/ProductList.jsx";
import useLocalStorage from "./hooks/useLocalStorage.js";

function App() {
  const [products, setProducts] = useLocalStorage('products',[]);
  

  const onAddProduct = (products) => setProducts((prev) => [...(Array.isArray(prev)? prev :[]),products]);



    
  const deleteProduct = (index) =>
    setProducts((prev) => (Array.isArray(prev) ? prev.filter((_, i) => i !== index) : prev));


  return (
    <div>
      <h1>Product Management Dashboard</h1>
      <ProductForm onAddProduct={onAddProduct} />
      <ProductList products={products} onDeleteProduct={deleteProduct}/>
    </div>
  );
}

export default App;
